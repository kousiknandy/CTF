! ! ! OWNED BY SintaLocker ! ! !

All your files are encrypted by SintaLocker with strong chiphers.
Decrypting of your files is only possible with the decryption program, which is on our secret server.
All encrypted files are moved to __SINTA I LOVE YOU__ directory and renamed to unique random name.
To receive your decryption program send $100 USD Bitcoin to address: 1NEdFjQN74ZKszVebFum8KFJNd9oayHFT1
Contact us after you send the money: sinpayy@yandex.com

Just inform your identification ID and we will give you next instruction.
Your personal identification ID: MAFIAMALWAREIDLRGT9JEA9F226

As your partner,

SintaLocker